import random
from library import center_window
from tkinter import *
from PIL import ImageTk, Image
import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
root=Tk()
root.geometry('1200x800')
root.title('Hangman')
center_window.center(root)

def hm():
    global num_of_tries,msg1,relevant_img,hm_img
    user_input1=user_input.get()
    
    for ids,chr in enumerate(randolist):
            if user_input1==chr:
                for widget in msgframe.winfo_children():
                    widget.destroy()
                a=[]
                
                for i in guessed_word:
                    if i=='__':
                        a.append(i)
                if len(a) <= len(guessed_word)-1:
                    for widget in wordframe.winfo_children():
                        widget.destroy()
                guessed_word[ids]=chr
                ohno.destroy()
                ohyes=Label(wordframe, text=guessed_word,width=60,font=20,pady=35)
                ohyes.pack(side='top',anchor='center')
                
    
    if len(user_input1) >1:
        for widget in msgframe.winfo_children():
            widget.destroy()
        display_img()
        num_of_tries -=1
        msg=Label(msgframe,text=f'Only input 1 letter at a time!\nYou have {num_of_tries} tries left', fg='red',font=14)
        msg.pack(side='top',anchor='center')
        
        if num_of_tries == 0:
                msg.destroy()
                msg1=Label(msgframe,text='You failed!',fg='red',font=14)
                msg1.pack(side='top',anchor='center')
                retry()
        
    elif user_input1 not in randolist:
            for widget in msgframe.winfo_children():
                widget.destroy()
            if num_of_tries == 1:
                for widget in pictframe.winfo_children():
                        widget.destroy()
                relevant_img=indx_img[-1]
                openhm=Image.open(relevant_img)
                hm_img=openhm.resize((300,300),Image.LANCZOS)
                hm_img=ImageTk.PhotoImage(hm_img)
                displayhm=Label(pictframe,image=hm_img)
                displayhm.pack(side='top',anchor='n')
                
                msg1=Label(msgframe,text='You failed!',fg='red',font=14)
                msg1.pack(side='top',anchor='center')
                retry()
                
                
            else:
                display_img()
                
                num_of_tries -=1        
                
                msg=Label(msgframe,text=f'Wrong guess! you have {num_of_tries} tries left.\nNumbers and symbols are not allowed!', fg='red',font=14)
                msg.pack(side='top',anchor='center')
    elif guessed_word == randolist:
        msg=Label(msgframe,text='you guessed the word!', fg='green',font=14)
        msg.pack(side='top',anchor='center')
        retry()
            
def display_img():
    global hm_img
    for widget in pictframe.winfo_children():
                        widget.destroy()
    relevant_img=indx_img[-num_of_tries]
    openhm=Image.open(relevant_img)
    hm_img=openhm.resize((300,300),Image.LANCZOS)
    hm_img=ImageTk.PhotoImage(hm_img)
    displayhm=Label(pictframe,image=hm_img)
    displayhm.pack(side='top',anchor='n')

def retry1():
    global rand_word,guessed_word,hm_img,file_path
    for widget in msgframe.winfo_children():
                        widget.destroy()
    for widget in wordframe.winfo_children():
                        widget.destroy()
    for widget in pictframe.winfo_children():
                        widget.destroy()
                        
    openhm=Image.open(file_path)
    hm_img=openhm.resize((300,300),Image.LANCZOS)
    hm_img=ImageTk.PhotoImage(hm_img)
    displayhm=Label(pictframe,image=hm_img)
    displayhm.pack(side='top',anchor='n')
    guessed_word=[]
    randword()
    ohno=Label(wordframe, text=guessed_word,width=60,font=20,pady=35)
    ohno.pack(side='top',anchor='center')
    user_input.config(state=NORMAL)
    submit_btn=Button(inputframe,text='Submit',bg='blue',font=12,width=15,command=hm)
    submit_btn.place(y=50,relx=0.5,rely=0.5,anchor='center')

def retry():
    global num_of_tries
    
    user_input.config(state=DISABLED)
    submit_btn.destroy()
    retry_btn=Button(inputframe,text='Retry',bg='blue',font=12,width=15,command=retry1)
    retry_btn.place(y=50,relx=0.5,rely=0.5,anchor='center')
    num_of_tries=6
def randword():
    global words, rand_word,randolist,guessed_word
    
    words=['google','church','method','green','praise','approval','corn','chocolate','basket','employee','transformative','aetosaurian','consider','contemplate','wedding','statement','guitar']
    rand_word=random.choice(words)
    randolist=[]
    for i in rand_word:
        randolist.append(i)

    
    for i in randolist:
        x=f'__'
        
        guessed_word.append(x)
num_of_tries=6


folder_path = os.path.join(os.path.dirname(__file__), 'library\\imgs')
file_path = os.path.join(folder_path, 'hm1.png')

pictframe=Frame(root, bg='white')
pictframe.pack(side='top', fill='x',expand=False, anchor='n')

openhm=Image.open(file_path)
hm_img=openhm.resize((300,300),Image.LANCZOS)
hm_img=ImageTk.PhotoImage(hm_img)
displayhm=Label(pictframe,image=hm_img)
displayhm.pack(side='top',anchor='n')
##
indx_img=[]
indx_img.append(os.path.join(folder_path, 'hm2.png'))
indx_img.append(os.path.join(folder_path, 'hm3.png'))
indx_img.append(os.path.join(folder_path, 'hm4.png'))
indx_img.append(os.path.join(folder_path, 'hm5.png'))
indx_img.append(os.path.join(folder_path, 'hm6.png'))
indx_img.append(os.path.join(folder_path, 'hm7_final.png'))

guessed_word=[]
randword()
wordframe=Frame(root,height=50)
wordframe.pack(side='top', fill='both',expand=False)
ohno=Label(wordframe, text=guessed_word,width=60,font=20,pady=35)
ohno.pack(side='top',anchor='center')
msgframe=Frame(root,height=50)
msgframe.pack(side='top',fill='both',anchor='center')
inputframe=Frame(root,height=300)
inputframe.pack(side='bottom', fill='both',expand=True, anchor='n')

Label(inputframe, text='Geuss a letter?').place(y=-50,relx=0.5,rely=0.5,anchor='center')
user_input=Entry(inputframe,font=12,width=15)
user_input.place(relx=0.5,rely=0.5,anchor='center')

submit_btn=Button(inputframe,text='Submit',bg='blue',font=12,width=15,command=hm)
submit_btn.place(y=50,relx=0.5,rely=0.5,anchor='center')


mainloop()